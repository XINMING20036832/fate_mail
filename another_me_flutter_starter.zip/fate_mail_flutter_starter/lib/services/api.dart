import 'package:http/http.dart' as http;

/// 未来对接后端的位置。
/// MVP阶段：不发真实网络请求，仅保留结构。
class ApiService {
  static String baseUrl = 'https://example.com';

  static Future<void> ping() async {
    // await http.get(Uri.parse('$baseUrl/ping'));
  }

  static Future<void> buyStamps({required int count}) async {}
  static Future<void> createRequest() async {}
  static Future<void> acceptRequest() async {}
  static Future<void> rejectRequest() async {}
  static Future<void> sendMail() async {}
  static Future<void> report() async {}
  static Future<void> blockUser() async {}
}
